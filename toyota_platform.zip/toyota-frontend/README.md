# Toyota Frontend

This is a minimal React app skeleton. Add your full React code here.

Remember to replace `BACKEND_URL` with your deployed backend URL.
