const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");

const app = express();
app.use(cors());
app.use(bodyParser.json());

let bookings = [];

function authenticate(req, res, next) {
  if (req.headers.authorization === "Bearer demo-token") {
    next();
  } else {
    res.status(401).json({ message: "Unauthorized" });
  }
}

app.post("/api/bookings", authenticate, (req, res) => {
  const { userPhone, carModel, pickupDate, returnDate } = req.body;
  if (!userPhone || !carModel || !pickupDate || !returnDate) {
    return res.status(400).json({ message: "Missing booking info" });
  }

  bookings.push({ id: bookings.length + 1, userPhone, carModel, pickupDate, returnDate });
  res.json({ message: "Booking created successfully" });
});

app.get("/api/bookings", authenticate, (req, res) => {
  const userPhone = req.query.userPhone;
  if (!userPhone) return res.status(400).json({ message: "Missing userPhone" });

  const userBookings = bookings.filter((b) => b.userPhone === userPhone);
  res.json(userBookings);
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Backend running on port ${PORT}`);
});
