import React, { useState } from "react";

const BACKEND_URL = "http://localhost:4000"; // Change after backend deploy

function App() {
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [invitationCode, setInvitationCode] = useState("");
  const [selectedModel, setSelectedModel] = useState("");
  const [pickupDate, setPickupDate] = useState("");
  const [returnDate, setReturnDate] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!selectedModel || !pickupDate || !returnDate) {
      alert("Please fill all booking fields");
      return;
    }
    if (new Date(returnDate) <= new Date(pickupDate)) {
      alert("Return date must be after pickup date");
      return;
    }
    setLoading(true);
    try {
      const token = "demo-token"; // Replace with real token after login
      const res = await fetch(`${BACKEND_URL}/api/bookings`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          userPhone: phone,
          carModel: selectedModel,
          pickupDate,
          returnDate,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        alert("Booking successful!");
        setSelectedModel("");
        setPickupDate("");
        setReturnDate("");
      } else {
        alert("Booking failed: " + data.message);
      }
    } catch (error) {
      alert("Error: " + error.message);
    }
    setLoading(false);
  };

  return (
    <div style={{ maxWidth: 400, margin: "auto", padding: 20 }}>
      <h1>TOYOTA CAR</h1>
      {/* You can add the Toyota car image here */}

      <form onSubmit={handleSubmit}>
        <div>
          <label>Phone (+251...):</label>
          <input
            type="text"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="+251 ..."
            required
          />
        </div>
        <div>
          <label>Password (6 digits):</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            maxLength={6}
            minLength={6}
            required
          />
        </div>
        <div>
          <label>Confirm Password:</label>
          <input
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            maxLength={6}
            minLength={6}
            required
          />
        </div>
        <div>
          <label>Invitation Code:</label>
          <input
            type="text"
            value={invitationCode}
            onChange={(e) => setInvitationCode(e.target.value)}
          />
        </div>

        <div>
          <label>Select Car Model:</label>
          <select
            value={selectedModel}
            onChange={(e) => setSelectedModel(e.target.value)}
            required
          >
            <option value="">--Choose--</option>
            <option value="Corolla">Corolla</option>
            <option value="Camry">Camry</option>
            <option value="RAV4">RAV4</option>
            <option value="Land Cruiser">Land Cruiser</option>
          </select>
        </div>

        <div>
          <label>Pickup Date:</label>
          <input
            type="date"
            value={pickupDate}
            onChange={(e) => setPickupDate(e.target.value)}
            required
          />
        </div>

        <div>
          <label>Return Date:</label>
          <input
            type="date"
            value={returnDate}
            onChange={(e) => setReturnDate(e.target.value)}
            required
          />
        </div>

        <button type="submit" disabled={loading}>
          {loading ? "Booking..." : "Book Now"}
        </button>
      </form>

      <div style={{ marginTop: 20 }}>
        Already have an account? <button onClick={() => alert("Go to Login")}>Login</button>
      </div>
    </div>
  );
}

export default App;
